const bg = document.body,
    switchBoard = document.getElementById('switch-board'),
    mainSwitch = document.getElementById('switch'),
    switchHeight = document.getElementById('switch-height'),
    onButton = document.getElementById('on'),
    offButton = document.getElementById('off');

onButton.addEventListener('click', turnOnLight);
offButton.addEventListener('click', turnOffLight);

function turnOnLight() {
    bg.style.backgroundColor = "white";
    switchBoard.classList.replace("switch-board-dark", "switch-board-light");
    switchHeight.classList.replace("switch-down", "switch-up");
    mainSwitch.classList.replace("switch-height-down", "switch-height-up");
    onButton.classList.replace("unpressed-on-color", "pressed-on-color");
    offButton.classList.replace("pressed-off-color", "unpressed-off-color");
}

function turnOffLight() {
    bg.style.backgroundColor = "black";
    switchBoard.classList.replace("switch-board-light", "switch-board-dark");
    switchHeight.classList.replace("switch-up", "switch-down");
    mainSwitch.classList.replace("switch-height-up", "switch-height-down");
    onButton.classList.replace("pressed-on-color", "unpressed-on-color");
    offButton.classList.replace("unpressed-off-color", "pressed-off-color");
};

